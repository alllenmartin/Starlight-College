<?php require 'php/fetch.php'; ?>
<?php require 'php/config_students.php'; ?>
<?php require 'php/display.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

   <title>Starlight College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

         <?php include('php/admin_nav.php'); ?>


        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">

                        <h3 class="page-header"><?php echo $email; ?>
                          
                        </h3>

                        
                    </div>
                    <!-- /.col-lg-12 -->
                    
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary" align="center">
                        <img src="images\<?php echo $images; ?>" style="width:100%;height:35vh;">
                       
                    </div>
                </div>
                 <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                               
                                <div class="col-xs-9 text-right">
                                   
                                    <div align="left">FIRST NAME</div>
                                     <h3 align=""><?php echo $firstname; ?></h3>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                 <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                               
                                <div class="col-xs-9 text-right">
                                   
                                    <div align="left">MIDDLE NAME</div>
                                     <h3 align=""><?php echo $middlename; ?></h3>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                 <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                               
                                <div class="col-xs-9 text-right">
                                   
                                    <div align="left">LAST NAME</div>
                                     <h3 align=""><?php echo $lastname; ?></h3>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                 <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                               
                                <div class="col-xs-9 text-right">
                                   
                                    <div align="left">ADM NUMBER</div>
                                     <h3 align=""><?php echo $admno; ?></h3>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                 <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                               
                                <div class="col-xs-9 text-right">
                                   
                                    <div align="left">EMAIL</div>
                                     <h3 align=""><?php echo $email; ?></h3>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                               
                                <div class="col-xs-9 text-right">
                                   
                                    <div align="left">MOBILE</div>
                                     <h3 align=""><?php echo $phoneno; ?></h3>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                </div>
                <div class="row">
                     <div class="col-lg-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            Success Panel
                        </div>
                        <div class="panel-body">
                             <div class="row">
                                  <div class="col-sm-4">GENDER :</div>
                                  <div class="col-sm-8"><em><?php echo $gender; ?></em></div>
                            </div> 
                             
                        </div>
                        <div class="panel-body">
                             <div class="row">
                                  <div class="col-sm-4">BIRTH DATE :</div>
                                  <div class="col-sm-8"><em><?php echo $dateofbirth; ?></em></div>
                            </div> 
                             
                        </div>
                        <div class="panel-footer">
                            Panel Footer
                        </div>
                    </div>
                </div>
                 <div class="col-lg-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            Success Panel
                        </div>
                        <div class="panel-body">
                             <div class="row">
                                  <div class="col-sm-4">PROGRAM :</div>
                                  <div class="col-sm-8"><em><?php echo $program; ?></em></div>
                            </div> 
                             
                        </div>
                        <div class="panel-body">
                             <div class="row">
                                  <div class="col-sm-4">REGION :</div>
                                  <div class="col-sm-8"><em><?php echo $region; ?></em></div>
                            </div> 
                             
                        </div>
                        <div class="panel-footer">
                            Panel Footer
                        </div>
                    </div>
                </div>
                     <div class="col-lg-6">
                        <div class="panel-body">
                         <p align=""> <a href="students.php"><button type="button" class="btn btn-default">BACK TO LIST</button></a>
                            <a href="edit students.php?np=<?php echo $data['admno']; ?>"><button type="button" class="btn btn-default">EDIT</button></a>
                         </p>
                         </div>

                         
                     </div>
                   
                    
                </div>
            
            </div>
            <!-- /.container-fluid --> 
        
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
