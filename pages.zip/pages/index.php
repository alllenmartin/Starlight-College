<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>STARLIGHT HOME PAGE</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<style type="text/css">
    body{
        overflow-x: hidden;
        /*overflow-y: hidden;*/
    }
</style>

<body>

    <div id="wrapper" class="panel-green" >

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top panel-green" role="navigation" style="margin-bottom: 0;background-color: #5cb85c
; ">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php" style="color:#ffffff;">STARLIGHT COLLEGE</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="lecturer_login.php"><i class="fa fa-lock fa-fw"></i>Lecturer Login</a>
                        </li>
                        <li><a href="admin login.php"><i class="fa fa-lock fa-fw"></i>Admin Login</a>
                        </li>
                        
                        
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> MAIN PAGE</a>
                        </li>
                         <li>
                            <a href="student login.php"><i class="fa fa-lock fa-fw"></i>Students Login</a>
                        </li>
                         <li>
                            <a href="register students.php"><i class="fa fa-user fa-fw"></i>Students Registration</a>
                        </li>
                       
                       
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper" >


            <div class="row">
                
                <div class="col-lg-12" align="center" >
                    <h3 class="page-header">STARLIGHT COLLEGE</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="jumbotron" style="background: url(images/awp-banner-gates.jpg) no-repeat;padding-top: 250px;">
                <div class="row" style="margin: -16%;">
                    <div class="col-md-4 col-md-offset-4" style="background: #303030; padding: 20px 28px;opacity: .8;color: #fff;">
                    <h2  class="text-center">Welcome to <strong>Starlight College</strong></h2>
                    <p class="text-center lead">We promote Education for all!</p>

                        
                    </div>
                    
                </div>
                
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <h2 class="text-info">Our Mission</h2>
                        <p class=""><b class="text-primary">Starlight College</b> aims at taking the education system of our nation to the next level.We offer quality and certified education to all the qualified students from all parts of the Republic.<br>We aim at providing quality and relevant education, training, research and community service for sustainable and economic development.</p>
                        
                    </div>
                     <div class="col-lg-6">
                        <h2 class="text-info">Our Vision</h2>
                        <p class=""><b class="text-primary">Starlight</b> mission is to be dynamic and innovative centre of excellence in teaching, learning, research and community service through provision of high quality and affordable training.</p>
                        
                    </div>
                    
                </div>
                
            </div>
                
            </div>
            
            <!-- /.row -->
            <!-- /.row -->
            
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
