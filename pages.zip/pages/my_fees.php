<?php
 if(empty($_GET['admno'])){
    array_push($errors,"You cannot access this page! please login first");
    header('location: index.php');

 }

?>
<?php include('php/DbConnect.php'); ?>
<?php include('php/course_reg.php');
include('php/fetch.php');
include('php/display.php');
?>
<?php include('php/display_students.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Star Light College | Student</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include('php/students_nav.php'); ?>
       <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Student Page </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

        
            <!-- /.row -->
            <div class="row">
                

                <div class="row">
                <div class="col-lg-12">
                 <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Basic Tabs
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#home" data-toggle="tab">Fees Balance</a>
                                </li>
                                <li><a href="#profile" data-toggle="tab">Fees Records</a>
                             
                               
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="home">
                                    <h4>Fee Balance</h4>
                                    <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Current Fee Balance
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                         <tr>
                                            <th></th>
                                            <th>Year</th>
                                            <th><?php echo $academic_year; ?></th>
                                           
                                        </tr>
                                          <tr>
                                            <th></th>
                                            <th>Semester</th>
                                            <th><?php echo $semester; ?></th>
                                           
                                        </tr>
                                        <tr>
                                            <th></th>
                                            <th>Fees Paid</th>
                                            <th><?php echo $amount; ?></th>
                                           
                                        </tr>
                                        <tr>
                                            <th></th>
                                            <th>Fees Balance</th>
                                            <th><?php echo $balance; ?></th>
                                            
                                        </tr>
                                        <tr>
                                            <th></th>
                                            <th>Percentage Paid</th>
                                            <th><?php echo $percentage.'%'; ?></th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="success">
                                            <td>1</td>
                                            <td>Total of All Fees Paid</td>
                                            <td><?php echo $qty; ?></td>
                                            
                                        </tr>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
                                </div>
                                <div class="tab-pane fade" id="profile">
                                   
                                    <div class="panel-heading lead">
                           All Fees Records
                        </div>
                        <div class="panel-body">
                             <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example" style="font-size: 11px;">
                                <thead>
                                    <tr style="font-weight: 900;">
                                        <td align="center" bgcolor="">Adm NO</td>
                                        <td align="center" bgcolor="">Amount</td>
                                        <td align="center" bgcolor="">Receipt NO</td>
                                        <td align="center" bgcolor="">Semester</td>
                                        <td align="center" bgcolor="">Year</td>
                                       
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php
  while($data = mysqli_fetch_array($resultSUMA)) {
    ?>
                                    <tr class="odd gradeX">
                                        <td><?php echo $data['admno']; ?></td>
                                         <td><?php echo $data['amount']; ?></td>
                                         <td><?php echo $data['receipt_no']; ?></td>
                                         <td><?php echo $data['semester']; ?></td>
                                       <td><?php echo $data['academic_year']; ?></td>
                                        
                                    </tr>
                                   <?php 
                                   }

                            ?>
                                    
                                </tbody>
                            </table>
                          
                        </div>
                        <div class="panel-footer">
                         <tr class="success">
                                            
                                            <td>Total of All Fees Paid =</td>
                                            <td><?php echo $qty; ?></td>
                                            
                                        </tr>
                        </div>
                                </div>
                                <div class="tab-pane fade" id="messages">
                                    <h4>Messages Tab</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                                <div class="tab-pane fade" id="settings">
                                    <h4>Settings Tab</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
        </div>

                      
                
                <!-- /.col-lg-8 -->
                
                
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
