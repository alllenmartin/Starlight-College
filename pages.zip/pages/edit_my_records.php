<?php require 'php/fetch.php'; ?>
<?php require 'php/config_students.php'; ?>
<?php require 'php/update.php'; ?>
<?php include("php/display.php"); ?>
 
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Starlight College</title>
    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

         <?php //include('php/student_nav.php'); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p class="page-header">EDIT &emsp;<?php echo $firstname; ?>&emsp;  <?php echo $middlename; ?> &emsp;RECORDS</p>
                        
                    </div>
                    <!-- /.col-lg-12 -->
                    
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="jumbotron">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                          UPDATE STUDENTS RECORDS <?php echo $admno; ?>
                        </div>
                        <div class="panel-body">
                            <form  role="form" method="POST" action="">
                                
                                <div class="col-lg-6">
                                    <p>Personal Details</p>
                                        <div class="form-group">
                                            <label>National ID</label>
                                            <input type="text" name="national_id" class="form-control" placeholder="National ID" value="<?php echo $national_id; ?>">
                                        </div>
                                       
                                         <div class="form-group">
                                            <label>First Name</label>
                                            <input type="text" name="firstname" class="form-control" placeholder="First Name" value="<?php echo $firstname; ?>">
                                        </div>
                                         <div class="form-group">
                                            <label>Middle Name</label>
                                            <input type="text" name="middlename" class="form-control" placeholder="Middle Name" value="<?php echo $middlename; ?>">
                                        </div>
                                         <div class="form-group">
                                            <label>Last Name</label>
                                            <input type="text" name="lastname" class="form-control" placeholder="Last Name" value="<?php echo $lastname; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo $email; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Mobile</label>
                                            <input type="text" name="phoneno" class="form-control" placeholder="Mobile Number" value="<?php echo $phoneno; ?>">
                                        </div>
                                       
                                        <div class="form-group">
                                            <label>Date Of Birth</label>
                                            <input type="date" name="dateofbirth" class="form-control" placeholder="Date Of Birth" value="<?php echo $dateofbirth; ?>">
                                        </div>
                                        
                                </div>

                                <div class="col-lg-6">
                                    <p>Educational Details</p>

                                    <div class="form-group">
                                            <label>Program</label>
                                            <select name="program" class="form-control">
                                                <option><?php echo $program; ?></option>
                                                <option autofocus="" >SELECT PROGRAM</option>
                                                 <?php
                   while($data = mysqli_fetch_array($resultP)) {
                    ?>
                                                <option value="<?php echo $data['program']; ?>"><?php echo $data['program']; ?></option>
                                                <?php 
                                            }

                    ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Region</label>
                                            <input type="text" name="region" class="form-control" placeholder="Region" value="<?php echo $region; ?>">
                                        </div>
                                        
                                        <button type="submit" name="updatest" class="btn btn-info">Submit</button>
                                        <button type="reset" class="btn btn-warning">Reset</button>
                                    
                                </div>
                            </form>
                        </div>
                        <div class="panel-footer">
                          WELCOME TO STARLIGHT COLLEGE
                        </div>
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                    
                </div>
            
            </div>
            <!-- /.container-fluid --> 
        
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
