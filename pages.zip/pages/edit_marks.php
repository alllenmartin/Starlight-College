<?php require 'php/update_marks.php'; ?>
<?php include('php/DbConnect.php'); ?>

<?php

 //LOGIN ADMIN


  if(isset($_GET['snoE']))
  {
    $snoE=$_GET['snoE'];
    $query=mysqli_query($db,"SELECT * FROM exams_tbl E INNER JOIN coursetbl C ON E.course_code=C.course_code WHERE E.snoE='$snoE' ");
    $dataa=mysqli_fetch_array($query);
   
    $snoE=$dataa['snoE'];
     $lecturersid=$dataa['lecturersid'];
      $marks=$dataa['marks'];
       $course_code=$dataa['course_code'];
       $course_title=$dataa['course_title'];
        $admno=$dataa['admno'];
         $semester=$dataa['semester'];
          $academic_year=$dataa['academic_year'];

    $queryL=mysqli_query($db,"SELECT * FROM lecturerstbl WHERE lecturersid='$lecturersid' ");
    $dataaL=mysqli_fetch_array($queryL);
     $lecturersidl=$dataaL['lecturersid'];
    $surnamel=$dataaL['surname'];
    $firstnamel=$dataaL['lfirstname'];
    $lastnamel=$dataaL['llastname'];
    $emaill=$dataaL['lemail'];
    $phonenol=$dataaL['lphoneno'];
    $coursecodel=$dataaL['coursecode'];
    $titlel=$dataaL['title'];
     $imagesl=$dataaL['images'];
   
   
  }else{
   
  
  }
  ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Starlight College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

          <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="admin home.php">Starlight College</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                       
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="lecturer_login.php?logoutl='1'"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="lecturer_marks.php?email=<?php echo $emaill; ?>"><i class="fa fa-table fa-fw"></i>Back</a>
                        </li>
                       
                      
                      
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-4">
                    <h1 class="page-header">My Student's Marks</h1>
                    <?php include('php/success.php'); ?>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                 <div class="col-lg-6">
                    <p>Details</p>
                  <div class="panel-body">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                
                                <tbody>
                                    <tr>
                                    <td><b>Adm NO</b></td>
                                <td><?php echo $admno; ?></td>
                                 </tr>
                                  <tr>
                                    <td><b>Course Code</b></td>
                                <td><?php echo $course_code; ?></td>
                                 </tr>
                                  <tr>
                                    <td><b>Course Title</b></td>
                                <td><?php echo $course_title; ?></td>
                                 </tr>
                                  <tr>
                                    <td><b>Semester</b></td>
                                <td><?php echo $semester; ?></td>
                                 </tr>
                                 <tr>
                                    <td><b>Session</b></td>
                                <td><?php echo $academic_year; ?></td>
                                 </tr>
                                 
                                </tbody>
                                   
                               
                            </table>
                    </div>
                    </div>
               <div class="col-lg-6">
                  <p>Update Mark</p>
                  <div class="panel-body">
                  
                        <form method="post" action="" role="form" >
                            <?php include('php/error.php'); ?>
                            <fieldset>
                                <div class="form-group">
                                    <label>Marks ID</label>
                                    <input class="form-control" placeholder="marks" name="snoE" type="text" autofocus value="<?php echo $snoE; ?>" readonly>
                                </div>
                                <div class="form-group" style="width:20%">
                                    <label>Marks</label>
                                    <input class="form-control" placeholder="Students Marks" name="marks" type="text" value="<?php echo $marks; ?> ">
                                </div>
                               
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" name="save" class="btn btn-lg btn-success btn-xs" value="Save">
                               
                            </fieldset>
                        </form>
                    </div>
                    </div>
                <!-- /.col-lg-12 -->
            </div>
           
            
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
