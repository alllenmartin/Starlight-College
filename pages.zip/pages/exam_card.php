<?php  ?>
<?php 
if(isset($_GET['admno']))
{
	include('php/DbConnect.php');
	$admno=$_GET['admno'];
	 $queryn=mysqli_query($db,"SELECT * FROM studentstbl WHERE admno='$admno'");
    $dataan=mysqli_fetch_array($queryn);
    $sno=$dataan['sno'];
    $firstname=$dataan['firstname'];
    $middlename=$dataan['middlename'];
    $lastname=$dataan['lastname'];
    $images=$dataan['images'];

function fetch_data()
{
	include('php/DbConnect.php');
	  $admno=$_GET['admno'];
	  $output = "";
    $yr= date("y");
     $queryn=mysqli_query($db,"SELECT * FROM nroll_tbl WHERE admno='$admno' AND  session='$yr' ORDER BY sno DESC LIMIT 1 ");
    $dataan=mysqli_fetch_array($queryn);
    
     $admno1=$dataan['admno'];
      $semester=$dataan['semester'];
     $academic_year=$dataan['academic_year'];

     /*$sqlCR = "SELECT * FROM course_reg_tbl crt INNER JOIN coursetbl c ON crt.course_code = c.course_code WHERE crt.admno = '$admno' AND crt.semester = '$semester' AND crt.academic_year = '$academic_year'  ";
    $resultCR = mysqli_query($db, $sqlCR);*/

  if ($admno1!="" && $semester!="" && $academic_year!="")
     {
     	$msg="";

     	$query=mysqli_query($db,"SELECT admno,amount FROM fees_tbl WHERE admno='$admno' AND semester='$semester' AND academic_year='$academic_year'");
    $dataa=mysqli_fetch_array($query);
    $admno=$dataa['admno'];
     $amount=$dataa['amount'];
     $fees='20000';

      if ($amount >= $fees) {
   //FETCH COURSES
     $sqlC = "SELECT * FROM coursetbl WHERE academic_year='$academic_year'";
    $resultC = mysqli_query($db, $sqlC);

     //FETCH COURSES
     $sqlCRp = "SELECT * FROM course_reg_tbl crt INNER JOIN coursetbl c ON crt.course_code = c.course_code WHERE crt.admno = '$admno' AND crt.semester = '$semester' AND crt.academic_year = '$academic_year'  ";
    $resultCRp = mysqli_query($db, $sqlCRp);

	while($row=mysqli_fetch_array($resultCRp))
	{
		$output .= '<tr style="font-size:7px;" border="1">
		                <td>'.$row["course_code"].'</td>
		                <td>'.$row["course_title"].'</td>
		                <td>'.$row["semester"].'</td>
		                <td>'.$row["academic_year"].'</td>
		                 <td>'."".'</td>
		                 <td>'."".'</td>
		                </tr>
		                ';
	}
	return $output;

}
}
}
}
if(isset($_POST["generate_pdf"]))
{
	require_once('tcpdf/tcpdf.php');
	$obj_pdf=new TCPDF('p', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
	$obj_pdf->SetCreator(PDF_CREATOR);
	//$obj_pdf->SetTittle("Generate HTML Table Data To PDF From Database Using TCPDF In PHP");
	$obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);
	$obj_pdf->SetHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
	$obj_pdf->SetFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	$obj_pdf->SetDefaultMonospacedFont('helvetica');
	$obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
	$obj_pdf->SetMargins(PDF_MARGIN_LEFT, '10',PDF_MARGIN_RIGHT);
	$obj_pdf->SetPrintHeader(false);
	$obj_pdf->SetPrintFooter(false);
	$obj_pdf->SetAutoPageBreak(true, 10);
	$obj_pdf->SetFont('helvetica', '', 11);
	$obj_pdf->AddPage();
	$content='';
	$content .= '
	<h4 align="center">STARLIGHT COLLEGE</h4><br />
	 <div class="col-lg-8" align="center">
                                  <p>EXAM CARD</p>
                        <table  class="table table-striped table-bordered table-hover" id="dataTables-example" style="font-size: 7px;left:0%;" align="center">
                        		<tr>
                        			<td><img src="images/'.$images.'" style="width:60px;width:100px;"></td>
                        		
                        		</tr>
                        		<tr>
                        			
                        			<td>'.$_GET['admno'].' '."".' '.$firstname.' '."".''.$middlename.' '."".''.$lastname.'</td>
                        			
                        			
                        		</tr>
                        	</table>

			<div class="panel-body" align="center">
			<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example" style="font-size: 11px;left:40%; border-spacing: 5px;" align="left">
				<tr border="2" style="font-size:10px;border:1px solid black;">
					<td>Course Code</td>
					<td>Course Title</td>
					<td>Semester</td>
					<td>Year</td>
					<td>Booklet NO</td>
					<td>Sign</td>
				</tr>
	     ';

	     $content .=fetch_data();
	     $content .='</table>
	     END
	     </div>
	     </div>';
	     $obj_pdf->writeHTML($content);
	     $obj_pdf->Output('EXAM CARD.pdf');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>GENERATE HTML TABLE DATA TO PDF FROM MYSQL DATABASE USING TCPDF IN PHP</title>
	 <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
	<br>
	  <div class="container" style="margin-top:-20%;">
       
            
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Students Exam Card</h3>
                    </div>
                    <div class="panel-body">
                    
		
		<div class="table-responsive" align="">
			<div class="">
				<form method="post" action="" target="_blank">
					<input type="submit" name="generate_pdf" class="btn btn-xs btn-success btn-block" value="Print Exam Card" style="width:10%;">
				</form>
			</div>
			<br>
			<br>
			 <div class="col-lg-12" align="center">
                                   <div class="panel-heading lead">
                           Exam Card
                        </div>
                        	<table width="70%" class="table table-striped table-bordered table-hover" id="dataTables-example" align="center">
                        		<tr>
                        			<td><img src="images/<?php echo $images; ?>" style="width:60px;width:100px;"></td>
                        			
                        		</tr>
                        		<tr>
                        			
                        			<td><?php echo $_GET['admno']; ?>&emsp;<?php echo $firstname; ?>&emsp;<?php echo $middlename; ?>&emsp;<?php echo $lastname; ?></td>
                        		
                        			
                        		</tr>
                        	</table>

			
			<table width="70%" class="table table-striped table-bordered table-hover" id="dataTables-example" style="font-size: 11px;left:40%;" align="center">
				<tr>
					<td>Course Code</td>
					<td>Course Title</td>
					<td>Semester</td>
					<td>Year</td>
					<td>Booklet</td>
					<td>Sign</td>
				</tr>
				<?php
				echo fetch_data();
				?>
			</table>
			</div>
		</div>
		
	
                    </div>
                </div>
            
        
      
    </div>
	 <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="..php/dist/js/sb-admin-2.js"></script>

</body>
</html>




  
