<?php
include('php/DbConnect.php');

if(isset($_GET['np'])) {
$np=$_GET['np'];
$sql="DELETE FROM studentstbl WHERE admno='$np'  ";
$sql=mysqli_query($db,$sql);
header('location: students.php');
}


if(isset($_GET['nl'])) {
$nl=$_GET['nl'];
$sql="DELETE FROM lecturerstbl WHERE lecturersid='$nl'  ";
$sql=mysqli_query($db,$sql);
header('location: lecturers.php');
}

if(isset($_GET['na'])) {
$na=$_GET['na'];
$sql="DELETE FROM admintbl WHERE adminid='$na'  ";
$sql=mysqli_query($db,$sql);
header('location: admins.php');
}

if(isset($_GET['nf'])) {
$nf=$_GET['nf'];
$sql="DELETE FROM fees_tbl WHERE sno='$nf'  ";
$sql=mysqli_query($db,$sql);
header('location: fees.php');
}

if(isset($_GET['nc'])) {
$nc=$_GET['nc'];
$sql="DELETE FROM coursetbl WHERE course_code='$nc'  ";
$sql=mysqli_query($db,$sql);
header('location: courses.php');
}


if(isset($_GET['nd'])) {
$nd=$_GET['nd'];
$sql="DELETE FROM departmentstbl WHERE dept_id='$nd'  ";
$sql=mysqli_query($db,$sql);
header('location: departments.php');
}
?>
<body>
	
</body>
