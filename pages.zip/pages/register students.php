<?php require 'php/fetch.php'; ?>
<?php require 'php/config_students.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

   <title>Starlight College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

         <nav class="navbar navbar-default navbar-static-top panel-green" role="navigation" style="margin-bottom: 0;background-color: #5cb85c
; ">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php" style="color:#ffffff;">STARLIGHT COLLEGE</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="staffs login.php"><i class="fa fa-lock fa-fw"></i>Lecturer Login</a>
                        </li>
                        <li><a href="admin login.php"><i class="fa fa-lock fa-fw"></i>Admin Login</a>
                        </li>
                        
                        
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> MAIN PAGE</a>
                        </li>
                         <li>
                            <a href="student login.php"><i class="fa fa-lock fa-fw"></i>Students Login</a>
                        </li>
                         <li>
                            <a href="register students.php"><i class="fa fa-user fa-fw"></i>Students Registration</a>
                        </li>
                       
                       
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">STUDENTS REGISTRATION FORM</h3>
                        
                    </div>
                    <!-- /.col-lg-12 -->
                    
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="jumbotron">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                           Students Registration Form
                        </div>
                        <div class="panel-body">
                            <form  role="form" method="POST" action="" enctype="multipart/form-data">
                                
                                <div class="col-lg-6">
                                    <p>Personal Details</p>
                                        <div class="form-group">
                                            <label>National ID</label>
                                            <input type="text" name="national_id" id="natid" class="form-control" placeholder="National ID">
                                        </div>
                                         <div class="form-group" style="display: none;">
                                            <label>Adm NO</label>
                                            <input type="text" name="admno" class="form-control" placeholder="Adm Number">
                                        </div>
                                         <div class="form-group">
                                            <label>First Name</label>
                                            <input type="text" name="firstname" class="form-control" placeholder="First Name">
                                        </div>
                                         <div class="form-group">
                                            <label>Middle Name</label>
                                            <input type="text" name="middlename" class="form-control" placeholder="Middle Name">
                                        </div>
                                         <div class="form-group">
                                            <label>Last Name</label>
                                            <input type="text" name="lastname" class="form-control" placeholder="Last Name">
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" name="email" class="form-control" placeholder="Email">
                                        </div>
                                        <div class="form-group">
                                            <label>Mobile</label>
                                            <input type="text" name="phoneno" class="form-control" placeholder="Mobile Number">
                                        </div>
                                        <div class="form-group">
                                            <label>Gender</label>
                                            <select name="gender" class="form-control">
                                                <option>MALE</option>
                                                <option>FEMALE</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Date Of Birth</label>
                                            <input type="date" name="dateofbirth" class="form-control" placeholder="Date Of Birth">
                                        </div>
                                        
                                </div>

                                <div class="col-lg-6">
                                    <p>Educational Details</p>

                                    <div class="form-group">
                                            <label>Program</label>
                                            <select name="program" class="form-control">
                                                <option autofocus="" >SELECT PROGRAM</option>
                                                 <?php
                   while($data = mysqli_fetch_array($resultP)) {
                    ?>
                                                <option value="<?php echo $data['program']; ?>"><?php echo $data['program']; ?></option>
                                                <?php 
                                            }

                    ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Region</label>
                                            <input type="text" name="region" class="form-control" placeholder="Region">
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" name="password" class="form-control" placeholder="Password">
                                        </div>
                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password" name="password2" class="form-control" placeholder="Confirm Password">
                                        </div>
                                        <div class="form-group">
                                            <label>Image</label>
                                            <input type="file" name="images">
                                        </div>
                                        <button type="submit" name="submits" class="btn btn-info">Submit</button>
                                        <button type="reset" class="btn btn-warning">Reset</button>
                                    
                                </div>
                            </form>
                        </div>
                        <div class="panel-footer">
                          WELCOME TO STARLIGHT COLLEGE
                        </div>
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                    
                </div>
            
            </div>
            <!-- /.container-fluid --> 
        
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
     <!-- masking-->
<script src="../js/inputmask.js"></script>
   <script src="../js/jquery.inputmask.js"></script>
    <script>  
    
 $(document).ready(function(){ 
 //input masking 
     $('#bcert').inputmask("99999999"); 
     $('#natid').inputmask("99999999");

      $('#county').change(function(){  
       // console.log("ggdd");
           var county_id = $(this).val();  
           $.ajax({  
                url:"loadsubcounties.php",  
                method:"POST",  
                data:{county_id:county_id},  
                success:function(data){  
                     $('#subcounty').html(data);  
                      
                }  
           });  
      });  
 });  
 </script>  

</body>

</html>
