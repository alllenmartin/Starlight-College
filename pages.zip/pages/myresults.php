<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Star Light College | Student</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
       <?php include('php/students_nav.php'); ?>
       <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Student Page <a href="studentprofile.php" style="float: right; "><button class="btn btn-default" style="border: none;"><span class="fa fa-user"></span>&nbsp;My Profile</button></a></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

        
            <!-- /.row -->
            <div class="row">
                
                <div class="row">
                <div class="col-lg-12">
                <div class="panel panel-default">
            
                <h2 align="center">My Results</h2>
                <div class="panel-heading"></div>
                    <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <td align="center" class="bg-success">Course Code</td>
                                        <td align="center" class="bg-success">Course Title</td>
                                        <td align="center" class="bg-success">Marks</td>
                                        <td align="center" class="bg-success">Grade</td>
                                        <td align="center" class="bg-success">Lecturer</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="odd gradeX">
                                        <td>COM 123</td>
                                        <td>MATHEMATICS FOR COMPUTER SCIENCE II</td>
                                        <td>75</td>
                                        <td>A</td>
                                        <td>MR. ALLEN JONES</td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td>COM 123</td>
                                        <td>MATHEMATICS FOR COMPUTER SCIENCE II</td>
                                        <td>75</td>
                                        <td>A</td>
                                        <td>MR. ALLEN JONES</td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td>COM 123</td>
                                        <td>MATHEMATICS FOR COMPUTER SCIENCE II</td>
                                        <td>75</td>
                                        <td>A</td>
                                        <td>MR. ALLEN JONES</td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td>COM 123</td>
                                        <td>MATHEMATICS FOR COMPUTER SCIENCE II</td>
                                        <td>75</td>
                                        <td>A</td>
                                        <td>MR. ALLEN JONES</td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td>COM 123</td>
                                        <td>MATHEMATICS FOR COMPUTER SCIENCE II</td>
                                        <td>75</td>
                                        <td>A</td>
                                        <td>MR. ALLEN JONES</td>
                                    </tr>
                                                      
                                </tbody>
                            </table>
                            <a href="student home.php"><button class="btn btn-primary">Back</button></a>
                        </div>
                </div>
                
                        <hr>
            </div>
        </div>

                      <div class="container">
                        <div class="row">
                          <div class="col-sm-4">
                            <h5>CURRENT NEWS</h5>
                            <p>..</p>
                            <p>...</p>
                          </div>
                          <div class="col-sm-4">
                            <h5>UPCOMING EVENTS</h5>
                            <p>..</p>
                            <p>...</p>
                          </div>
                          <div class="col-sm-4">
                            <h5>CALENDER</h5>
                            <p>..</p>
                            <p>...</p>
                          </div>
                        </div>
                      </div> 
                
                <!-- /.col-lg-8 -->
                <div class="col-lg-8">
                    <p>We’re grateful for the opportunity to submit our proposal for creating an online portal system for the institution which we believe is going to offer permanent solutions to some of the needs which we are going address in this project.</p>

                    <!-- /.panel -->
                    <div class="chat-panel panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-comments fa-fw"></i> Chat
                            <div class="btn-group pull-right">
                                <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-chevron-down"></i>
                                </button>
                                <ul class="dropdown-menu slidedown">
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-refresh fa-fw"></i> Refresh
                                        </a>
                                    </li>
                                  
                                </ul>
                            </div>
                        </div>
                       
                        <!-- /.panel-body -->
                        <div class="panel-footer">
                            <div class="input-group">
                                <input id="btn-input" type="text" class="form-control input-sm" placeholder="Type your message here..." />
                                <span class="input-group-btn">
                                    <button class="btn btn-warning btn-sm" id="btn-chat">
                                        Send
                                    </button>
                                </span>
                            </div>
                        </div>
                        <!-- /.panel-footer -->
                    </div>
                </div>
               
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
