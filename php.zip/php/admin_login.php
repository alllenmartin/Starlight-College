<?php
include('DbConnect.php');

$errors= array();
//log user in
if (isset($_POST['adminlogin'])) {
	$email =mysqli_real_escape_string($db,$_POST['email']);
	$passworda = mysqli_real_escape_string($db,$_POST['passworda']);
		
	if (count($errors)==0) {
		$passworda = md5($passworda);//encrypt password before comparing with one from db
		$query = "SELECT * FROM admintbl WHERE email ='$email' AND passworda ='$passworda'";
		$result=mysqli_query($db, $query);
		if (mysqli_num_rows($result)==1) {
	
		$_SESSIONS['email']=$email;
		$_SESSIONS['success']="You are now logged in";
		header('location:admin home.php?email='.$email);//redirect to home page
		exit();
		}else{
			 array_push($errors,"Wrong username/password combination!");
			
		}
	}

}


if (isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION['email']);
	header('location: admin login.php');

}


?>


<?php
include('DbConnect.php');

$errors= array();
//log user in
if (isset($_POST['lecturerlogin'])) {
	$email =mysqli_real_escape_string($db,$_POST['email']);
	$passworda = mysqli_real_escape_string($db,$_POST['passworda']);
		
	if (count($errors)==0) {
		$passworda = md5($passworda);//encrypt password before comparing with one from db
		$query = "SELECT * FROM lecturerstbl WHERE email ='$email' AND passworda ='$passworda'";
		$result=mysqli_query($db, $query);
		if (mysqli_num_rows($result)==1) {
	
		$_SESSIONS['email']=$email;
		$_SESSIONS['success']="You are now logged in";
		header('location:lecturer_home.php?email='.$email);//redirect to home page
		exit();
		}else{
			 array_push($errors,"Wrong username/password combination!");
			
		}
	}

}


if (isset($_GET['logoutl'])){
	session_destroy();
	unset($_SESSION['email']);
	header('location: lecturer_login.php');

}


?>