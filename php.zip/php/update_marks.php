<?php include('DbConnect.php'); ?>


<?php

 //LOGIN ADMIN


  if(isset($_POST['save']))
{ 
   
    $snoE=$_POST['snoE'];
    $marks=$_POST['marks'];

    $sql="UPDATE exams_tbl SET marks='$marks' WHERE snoE='$snoE'";
    $query=mysqli_query($db,$sql);

    if($query){
       header('location: edit_marks.php?snoE='.$snoE);
    }else{
        echo "error has occured";
    }   
    }
  ?>