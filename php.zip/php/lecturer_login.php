<?php
include('DbConnect.php');

$errors= array();
//log user in
if (isset($_POST['lecturerlogin'])) {
	$lemail =mysqli_real_escape_string($db,$_POST['lemail']);
	$passwordl = mysqli_real_escape_string($db,$_POST['passwordl']);
		
	if (count($errors)==0) {
		$passwordl = md5($passwordl);//encrypt password before comparing with one from db
		$query = "SELECT * FROM lecturerstbl WHERE lemail ='$lemail' AND passwordl ='$passwordl'";
		$result=mysqli_query($db, $query);
		if (mysqli_num_rows($result)==1) {
	
		$_SESSIONS['lemail']=$lemail;
		$_SESSIONS['success']="You are now logged in";
		header('location:lecturer_home.php?email='.$lemail);//redirect to home page
		exit();
		}else{
			 array_push($errors,"Wrong username/password combination!");
			
		}
	}

}


if (isset($_GET['logoutl'])){
	session_destroy();
	unset($_SESSION['email']);
	header('location: lecturer_login.php');

}


?>