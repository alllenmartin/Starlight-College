<?php

$servername="localhost";
$username="root";
$password="";
$dbname="starlightdb";
$errors = array();

//create connection
$db=new mysqli($servername,$username,$password,$dbname);


//check connection
if($db->connect_error){
	die("connection filed" . $db->connect_error);
	echo "Connection Failled";
}else{
	

}

?>