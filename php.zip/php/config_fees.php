<?php
include('DbConnect.php');
if (isset($_POST['submitf']))
{
	$admno=$_POST['admno'];
	$amount=$_POST['amount'];
	$receipt_no=$_POST['receipt_no'];
	$bank_name=$_POST['bank_name'];
	$branch=$_POST['branch'];
	$semester=$_POST['semester'];
	$academic_year=$_POST['academic_year'];
	$session= $_POST['session'];

	$sql="INSERT INTO fees_tbl (admno,amount,receipt_no,bank_name,branch,semester,academic_year,session) VALUES ('$admno','$amount','$receipt_no','$bank_name', '$branch','$semester','$academic_year','$session')";
	$query=mysqli_query($db,$sql);

	if($query)
	{
		header('location: fees.php');
	}else{
		echo "ERROR OCCURED";
	}
}


//register courses
if (isset($_POST['addcourse']))
{
	$course_code=$_POST['course_code'];
	$course_title=$_POST['course_title'];
	$dept_id=$_POST['dept_id'];
	$academic_year=$_POST['academic_year'];
	

	$sql="INSERT INTO coursetbl (course_code,course_title,dept_id,academic_year) VALUES ('$course_code','$course_title','$dept_id','$academic_year')";
	$query=mysqli_query($db,$sql);

	if($query)
	{
		header('location: courses.php');
	}else{
		echo "ERROR OCCURED";
	}
}



//register departments
if (isset($_POST['adddept']))
{
	$dept_id=$_POST['dept_id'];
	$dept_name=$_POST['dept_name'];
	$dept_type=$_POST['dept_type'];
	
	

	$sql="INSERT INTO departmentstbl (dept_id,dept_name,dept_type) VALUES ('$dept_id','$dept_name','$dept_type')";
	$query=mysqli_query($db,$sql);

	if($query)
	{
		header('location: departments.php');
	}else{
		echo "ERROR OCCURED";
	}
}



//Norminal Roll
if (isset($_POST['submitNROLL']))
{
	$admno=$_POST['admno'];
	$session=$_POST['session'];
	$semester=$_POST['semester'];
	$academic_year=$_POST['academic_year'];
	
	

	$sql="INSERT INTO nroll_tbl (admno,semester,academic_year,session) VALUES ('$admno','$semester','$academic_year','$session')";
	$query=mysqli_query($db,$sql);

	if($query)
	{
		 array_push($errors,"Norminal Roll Successfully Updated. Proceed To register courses");
	}else{
		echo "ERROR OCCURED";
	}
}

//Norminal Roll
if (isset($_POST['submitCourse']))
{
	$admno=$_POST['admno'];
	$course_code=$_POST['course_code'];
	$semester=$_POST['semester'];
	$academic_year=$_POST['academic_year'];
	
	

	$sql="INSERT INTO course_reg_tbl (admno,course_code,semester,academic_year) VALUES ('$admno','$course_code','$semester','$academic_year')";
	$query=mysqli_query($db,$sql);

	if($query)
	{
		 array_push($errors,"One Course Successfully Registered");
	}else{
		echo "ERROR OCCURED";
	}
}



//ADD LEC COURSE
if (isset($_POST['addleccourse']))
{
	$lecturersid=$_POST['lecturersid'];
	$course_code=$_POST['course_code'];
	
	
	
	

	$sql="INSERT INTO lec_courses_tbl (lecturersid,course_code) VALUES ('$lecturersid','$course_code')";
	$query=mysqli_query($db,$sql);

	if($query)
	{
		 array_push($errors,"One Course Successfully Registered");
	}else{
		echo "ERROR OCCURED";
	}
}
?>