<?php include('DbConnect.php'); ?>
<?php
//edit details

if(isset($_POST['updates']))
{ 
	$national_id=$_POST['national_id'];
	$admno=$_POST['admno'];
	$firstname=$_POST['firstname'];
	$middlename=$_POST['middlename'];
	$lastname=$_POST['lastname'];
	$email=$_POST['email'];
	$phoneno=$_POST['phoneno'];
	$program=$_POST['program'];
	$region=$_POST['region'];

	$sql="UPDATE studentstbl SET admno='$admno', firstname='$firstname', middlename='$middlename', lastname='$lastname', email='$email', phoneno='$phoneno', program='$program', region='$region'  WHERE national_id='$national_id'";
	$query=mysqli_query($db,$sql);

	if($query){
		header('location: students.php');
	}else{
		echo "error has occured";
	}	
	}
	?>
<?php
//edit details

if(isset($_POST['updatest']))
{ 
	$national_id=$_POST['national_id'];
	
	$firstname=$_POST['firstname'];
	$middlename=$_POST['middlename'];
	$lastname=$_POST['lastname'];
	$email=$_POST['email'];
	$phoneno=$_POST['phoneno'];
	$program=$_POST['program'];
	$region=$_POST['region'];

	$sql="UPDATE studentstbl SET firstname='$firstname', middlename='$middlename', lastname='$lastname', email='$email', phoneno='$phoneno', program='$program', region='$region'  WHERE national_id='$national_id'";
	$query=mysqli_query($db,$sql);
    
	if($query){
		header('location: student home.php?email='.$email);
	}else{
		echo "error has occured";
	}	
	}
	?>

	<?php
//edit ADMIN DETAILS

if(isset($_POST['updatea']))
{ 
	$adminid=$_POST['adminid'];
	$username=$_POST['username'];
	$middlename=$_POST['middlename'];
	$lastname=$_POST['lastname'];
	$email=$_POST['email'];
	$phoneno=$_POST['phoneno'];
	$department=$_POST['department'];
	$active=$_POST['active'];

	$sql="UPDATE admintbl SET username='$username', lastname='$lastname', email='$email', phoneno='$phoneno', department='$department', active='$active'  WHERE adminid='$adminid'";
	$query=mysqli_query($db,$sql);

	if($query){
		header('location: admins.php');
	}else{
		echo "error has occured";
	}	
	}
	?>


	<?php
//edit LECTURER DETAILS

if(isset($_POST['updatel']))
{ 
	$lecturersid=$_POST['lecturersid'];
	$sirname=$_POST['sirname'];
	$lfirstname=$_POST['lfirstname'];
	$llastname=$_POST['llastname'];
	$lemail=$_POST['lemail'];
	$lphoneno=$_POST['lphoneno'];
	$title=$_POST['title'];
	

	$sql="UPDATE lecturerstbl SET sirname='$sirname', lfirstname='$lfirstname', llastname='$llastname', lemail='$lemail', lphoneno='$lphoneno', title='$title' WHERE lecturersid='$lecturersid'";
	$query=mysqli_query($db,$sql);

	if($query){
		header('location: lecturers.php');
	}else{
		echo "error has occured";
	}	
	}
	?>


	


  