<?php
include('DbConnect.php');
$email="";
$password="";
$errors= array();
//log user in
if (isset($_POST['login'])) {
	$email =mysqli_real_escape_string($db,$_POST['email']);
	$password = mysqli_real_escape_string($db,$_POST['password']);
		
	if (count($errors)==0) {
		//$password = md5($password);//encrypt password before comparing with one from db
		 $queryf=mysqli_query($db,"SELECT * FROM studentstbl WHERE email='$email' ");
        $data=mysqli_fetch_array($queryf);
		$admno=$data['admno'];
		if ($admno=='')
		{
			 array_push($errors,"Complete Registration by paying Fees");

		}else{
			$query = "SELECT * FROM studentstbl WHERE admno!='' AND  email ='$email' AND password ='$password'";
		$result=mysqli_query($db, $query);
		$data=mysqli_fetch_array($result);
		$admno=$data['admno'];
		if (mysqli_num_rows($result)==1) {
	
		$_SESSION['email']=$email;
		$_SESSION['success']="You are now logged in";
		header('location:student home.php?email='.$email);//redirect to home page
		}else{
			 array_push($errors,"Wrong username/password combination!");
			
		}

		}


		
	}

}


if (isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION['email']);
	header('location: student login.php');

}


?>