<?php include("php/DbConnect.php"); ?>
<?php

 //VIEW STUDENTS


  if(isset($_GET['email']))
  {
    $email=$_GET['email'];
    $query=mysqli_query($db,"SELECT * FROM studentstbl WHERE email='$email' ");
    $data=mysqli_fetch_array($query);
    $admno=$data['admno'];
    $firstname=$data['firstname'];
    $middlename=$data['middlename'];
    $lastname=$data['lastname'];
    $email=$data['email'];
    $gender=$data['gender'];
    $phoneno=$data['phoneno'];
    $dateofbirth=$data['dateofbirth'];
    $program=$data['program'];
    $region=$data['region'];
     $images=$data['images'];
   
  }else{
   
  
  }
  ?>

  <?php

 //VIEW STUDENTS


  if(isset($_GET['admno']))
  {
    $admno=$_GET['admno'];
    $query=mysqli_query($db,"SELECT * FROM studentstbl WHERE admno='$admno' ");
    $data=mysqli_fetch_array($query);
    $sno=$data['sno'];
    $admno=$data['admno'];
    $firstname=$data['firstname'];
    $middlename=$data['middlename'];
    $lastname=$data['lastname'];
    $email=$data['email'];
    $gender=$data['gender'];
    $phoneno=$data['phoneno'];
    $dateofbirth=$data['dateofbirth'];
    $program=$data['program'];
    $region=$data['region'];
     $images=$data['images'];
   
  }else{
   
  
  }
  ?>