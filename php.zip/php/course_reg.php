<?php include("php/DbConnect.php"); ?>
<?php 
//SET AMOUNT OF FEES TO BE PAID
$fees='20000';
//THIS GETS THE ADM NO
if(isset($_GET['admno']))
  {
    //SETS THE GOTTEN ADM AND SET IT TO $admno
    $admno=$_GET['admno'];
    //GETS THE CURRENT YR AND SET IT TO $yr
    $yr= date("y");
    //
     $queryn=mysqli_query($db,"SELECT * FROM nroll_tbl WHERE admno='$admno' AND  session='$yr' ORDER BY sno DESC LIMIT 1 ");
    $dataan=mysqli_fetch_array($queryn);
    
     $admno1=$dataan['admno'];
      $semester=$dataan['semester'];
     $academic_year=$dataan['academic_year'];

   
  //CHECKS IF ALL THE BELOW VARIABLES ARE NOT EMPTY
  if ($admno1!=="" && $semester!=="" && $academic_year!=="")
     {
     	$msg="";

     	$query=mysqli_query($db,"SELECT admno,amount FROM fees_tbl WHERE admno='$admno' AND semester='$semester' AND academic_year='$academic_year'");
    $dataa=mysqli_fetch_array($query);
    $admno=$dataa['admno'];
     $amount=$dataa['amount'];
//CHECK 
      if ($amount >= $fees) {
   //FETCH COURSES
     $sqlC = "SELECT * FROM coursetbl WHERE academic_year='$academic_year'";
    $resultC = mysqli_query($db, $sqlC);

     //FETCH COURSES
     $sqlCR = "SELECT * FROM course_reg_tbl crt INNER JOIN coursetbl c ON crt.course_code = c.course_code WHERE crt.admno = '$admno' AND crt.semester = '$semester' AND crt.academic_year = '$academic_year'  ";
    $resultCR = mysqli_query($db, $sqlCR);




    
} else {
	//FETCH COURSES
     $sqlCR = "SELECT * FROM divert_tbl ";
    $resultCR = mysqli_query($db, $sqlCR);
    $msg= "PLEASE PAY 100$ SCHOOL FEES BEFORE YOU CAN REGISTER COURSES FOR $academic_year $semester";
}


// echo $admno1;
// echo "-";
// echo $semester;
// echo "-";
// echo $academic_year;
// echo "-";
// echo date('y');

     }
   
  }else{
   
   //header('location:student login.php');
  
  }
//CALCULATE FEE BALANCE
$balance= $fees - $amount;
//CALCULATE FEE BALANCE PERCENTAGE
$percentage=($amount*100)/$fees;

 //PROGRAMS
     $sqlSUM = "SELECT * FROM fees_tbl WHERE admno='$admno'";
    $resultSUM = mysqli_query($db, $sqlSUM);
    //INITIALIZES THE TOTAL AMOUNT OF FEES PAID
    $qty=0;
     while($datas = mysqli_fetch_array($resultSUM))
     {
      //CALCULATES THE TOTAL AMOUNT
      $qty += $datas['amount'];
     }


     
//FEES
     $sqlSUMA = "SELECT * FROM fees_tbl WHERE admno='$admno'";
    $resultSUMA = mysqli_query($db, $sqlSUMA);


//FEES
     $sqlexams = "SELECT * FROM exams_tbl et INNER JOIN coursetbl ct ON et.course_code=ct.course_code WHERE admno='$admno'";
    $resultexams = mysqli_query($db, $sqlexams);
?>