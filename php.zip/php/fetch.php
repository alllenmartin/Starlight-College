<?php 
$yr="";
$db=mysqli_connect("localhost","root","","starlightdb");
//all students
    $sql = "SELECT * FROM studentstbl WHERE admno='' ";
    $result = mysqli_query($db, $sql);

    //first years
  
     $sqlf = "SELECT * FROM studentstbl INNER JOIN fees_tbl ON studentstbl.admno=fees_tbl.admno WHERE fees_tbl.academic_year = 'FIRST YEAR' AND session='".date("y")."'  ";
    $resultf = mysqli_query($db, $sqlf);

    //second years
     $sqls = "SELECT * FROM studentstbl INNER JOIN fees_tbl ON studentstbl.admno=fees_tbl.admno WHERE academic_year = 'SECOND YEAR' AND session='".date("y")."'  ";
    $results = mysqli_query($db, $sqls);


     //third years
     $sqlt = "SELECT * FROM studentstbl INNER JOIN fees_tbl ON studentstbl.admno=fees_tbl.admno WHERE academic_year = 'THIRD YEAR' AND session='".date("y")."'  ";
    $resultt = mysqli_query($db, $sqlt);


     //PROGRAMS
     $sqlP = "SELECT * FROM program_tbl";
    $resultP = mysqli_query($db, $sqlP);
    

    //lecturers
    //PROGRAMS
     $sqlL = "SELECT * FROM lecturerstbl";
    $resultL = mysqli_query($db, $sqlL);


    //Fees years
     $sqlfs = "SELECT * FROM studentstbl INNER JOIN fees_tbl ON studentstbl.admno=fees_tbl.admno";
    $resultfs = mysqli_query($db, $sqlfs);



     //FETCH SEMESTER
     $sqlsem = "SELECT * FROM sem_tbl";
    $resultsem = mysqli_query($db, $sqlsem);


     //FETCH COURSES
     $sqlfc = "SELECT * FROM coursetbl INNER JOIN departmentstbl ON coursetbl.dept_id=departmentstbl.dept_id";
    $resultfc = mysqli_query($db, $sqlfc);



    //FETCH ACADEMIC DEPARTMENTS
     $sqldept = "SELECT * FROM departmentstbl WHERE dept_type='ACADEMICS'  ";
    $resultdept = mysqli_query($db, $sqldept);


    //FETCH ADMINS
     $sqladmin = "SELECT * FROM admintbl";
    $resultadmin = mysqli_query($db, $sqladmin);

    //FETCH MANAGEMENT DEPARTMENTS
     $sqldeptm = "SELECT * FROM departmentstbl WHERE dept_type='MANAGEMENT'  ";
    $resultdeptm = mysqli_query($db, $sqldeptm);


    //FETCH SEMESTER
     $sqlyr = "SELECT * FROM academic_yr_tbl";
    $resultyr = mysqli_query($db, $sqlyr);

    //FETCH BRANCH
     $sqlyr = "SELECT * FROM branch_tbl";
    $resultbranch = mysqli_query($db, $sqlyr);


    //first years exams
     $sqlfe = "SELECT * FROM studentstbl INNER JOIN exams_tbl ON studentstbl.admno=exams_tbl.admno WHERE academic_year = 'FIRST YEAR' ";
    $resultfe = mysqli_query($db, $sqlfe);


    //SECOND YEARS years exams
     $sqlfe = "SELECT * FROM studentstbl INNER JOIN exams_tbl ON studentstbl.admno=exams_tbl.admno WHERE academic_year = 'SECOND YEAR' ";
    $resultse = mysqli_query($db, $sqlfe);

    //third years exams
     $sqlfe = "SELECT * FROM studentstbl INNER JOIN exams_tbl ON studentstbl.admno=exams_tbl.admno WHERE academic_year = 'THIRD YEAR' ";
    $resultte = mysqli_query($db, $sqlfe);


     //first years exams
     $sqlfe = "SELECT * FROM studentstbl INNER JOIN exams_tbl ON studentstbl.admno=exams_tbl.admno ";
    $resultallexams = mysqli_query($db, $sqlfe);

     //FETCH COURSE TO ADD LEC COURSE
     $sqlalc = "SELECT * FROM coursetbl";
    $resultleccourse = mysqli_query($db, $sqlalc);

 ?>