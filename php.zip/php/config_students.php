<?php
include('DbConnect.php');
session_start();
$target="images/";
$national_id="";
$firstname="";
$middlename="";
$lastname="";
$email="";
$phoneno="";
$gender="";
$dateofbirth="";
$program="";
$region="";
$images="";
$password="";
$password2="";
$errors= array();
//connect to the db
//$db = mysqli_connect('localhost','root','','registration');


//if the register button is clicked
if(isset($_POST['submits'])) {
	$national_id =mysqli_real_escape_string($db,$_POST['national_id']);
	$firstname = mysqli_real_escape_string($db,$_POST['firstname']);
	$middlename = mysqli_real_escape_string($db,$_POST['middlename']);
	$lastname = mysqli_real_escape_string($db,$_POST['lastname']);
	$email = mysqli_real_escape_string($db,$_POST['email']);
	$gender = mysqli_real_escape_string($db,$_POST['gender']);
	$dateofbirth = mysqli_real_escape_string($db,$_POST['dateofbirth']);
	$phoneno = mysqli_real_escape_string($db,$_POST['phoneno']);
	$program = mysqli_real_escape_string($db,$_POST['program']);
	$region = mysqli_real_escape_string($db,$_POST['region']);

	//image upload
	$target="images/".basename($_FILES["images"]["name"]);
    $images=mysqli_real_escape_string($db,$_FILES['images']['name']);

	$password= mysqli_real_escape_string($db,$_POST['password']);
	$password2= mysqli_real_escape_string($db,$_POST['password2']);


	if ($password !=$password2){
		array_push($errors,"Password do not match");
	}
	
	

	//if there are no errors save the data to the database
	if (count($errors)==0) {
		//$password = md5($password); //encrypt password before storing in database
	$sql="INSERT INTO studentstbl (national_id,firstname,middlename,lastname,email,gender,dateofbirth,phoneno,program,region,images,password) VALUES ('$national_id', '$firstname','$middlename','$lastname','$email', '$gender','$dateofbirth','$phoneno', '$program', '$region','$images', '$password')";
		mysqli_query($db, $sql );
		$_SESSION1['national_id']=$national_id;
		$_SESSION1['success']="Registered Successifully";
		header('location:student login.php');//redirect to home page
		

		if (move_uploaded_file($_FILES['images']['tmp_name'], $target)) {
		$msg="Image Uploaded successifully";

	}else{
		$msg="There is a problem detected";
	}
	}
	
}


 
//register admins
$target="images/";
$adminid="";
$username="";
$lastname="";
$email="";
$phoneno="";
$department="";
$active="";
$images="";
$passworda="";
$passworda2="";

$errors= array();
//connect to the db
//$db = mysqli_connect('localhost','root','','registration');


//if the register button is clicked
if(isset($_POST['submita'])) {
	
	$adminid =mysqli_real_escape_string($db,$_POST['adminid']);
	$username = mysqli_real_escape_string($db,$_POST['username']);
	
	$lastname = mysqli_real_escape_string($db,$_POST['lastname']);
	$email = mysqli_real_escape_string($db,$_POST['email']);
	
	$phoneno = mysqli_real_escape_string($db,$_POST['phoneno']);
	$department = mysqli_real_escape_string($db,$_POST['department']);
	$active = mysqli_real_escape_string($db,$_POST['active']);

	//image upload
	$target="images/".basename($_FILES["images"]["name"]);
    $images=mysqli_real_escape_string($db,$_FILES['images']['name']);
	$passworda= mysqli_real_escape_string($db,$_POST['passworda']);
	$passworda2= mysqli_real_escape_string($db,$_POST['passworda2']);


	if ($password !=$password2){
		array_push($errors,"Password do not match");
	}
	
	

	//if there are no errors save the data to the database
	if (count($errors)==0) {
		$passworda = md5($passworda); //encrypt password before storing in database
	$sqla="INSERT INTO admintbl (adminid,username,lastname,email,phoneno,department,active,images,passworda) VALUES ('$adminid', '$username','$lastname','$email','$phoneno', '$department', '$active','$images', '$passworda')";
		mysqli_query($db, $sqla );
		$_SESSION['adminid']=$adminid;
		$_SESSION['success']="Registered Successifully";
		header('location:admins.php');//redirect to home page
		exit();

		if (move_uploaded_file($_FILES['images']['tmp_name'], $target)) {
		$msg="Image Uploaded successifully";

	}else{
		$msg="There is a problem detected";
	}
	}
	
}

//lecturer registration
$target="images/";
$lecturersid="";
$surname="";
$lfirstname="";
$llastname="";
$title="";
$lemail="";
$lphoneno="";
$program="";
$passwordl="";
$passwordl2="";

$errors= array();
//connect to the db
//$db = mysqli_connect('localhost','root','','registration');


//if the register button is clicked
if(isset($_POST['submitl'])) {
	
	$lecturersid =mysqli_real_escape_string($db,$_POST['lecturersid']);
	$surname = mysqli_real_escape_string($db,$_POST['surname']);
	$lfirstname = mysqli_real_escape_string($db,$_POST['lfirstname']);
	
	$llastname = mysqli_real_escape_string($db,$_POST['llastname']);
	$lemail = mysqli_real_escape_string($db,$_POST['lemail']);
	
	$lphoneno = mysqli_real_escape_string($db,$_POST['lphoneno']);
	$program = mysqli_real_escape_string($db,$_POST['program']);
	$title = mysqli_real_escape_string($db,$_POST['title']);

	//image upload
	$target="images/".basename($_FILES["images"]["name"]);
    $images=mysqli_real_escape_string($db,$_FILES['images']['name']);
	$passwordl= mysqli_real_escape_string($db,$_POST['passwordl']);
	$passwordl2= mysqli_real_escape_string($db,$_POST['passwordl2']);


	if ($passwordl!=$passwordl2){
		array_push($errors,"Password do not match");
	}
	
	

	//if there are no errors save the data to the database
	if (count($errors)==0) {
		$passwordl = md5($passwordl); //encrypt password before storing in database
	$sqla="INSERT INTO lecturerstbl (lecturersid,surname,lfirstname,llastname,lemail,lphoneno,title,program,images,passwordl) VALUES ('$lecturersid', '$surname','$lfirstname','$llastname','$lemail','$lphoneno','$title', '$program','$images','$passwordl')";
		mysqli_query($db, $sqla );
		$_SESSION['lecturersid']=$lecturersid;
		$_SESSION['success']="Registered Successifully";
		header('location:lecturers.php');//redirect to home page
		exit();

		if (move_uploaded_file($_FILES['images']['tmp_name'], $target)) {
		$msg="Image Uploaded successifully";

	}else{
		$msg="There is a problem detected";
	}
	}
	
}


?>




