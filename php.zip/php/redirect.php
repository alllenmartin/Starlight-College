<?php
 if(empty($_SESSION['username'])){
 	array_push($errors,"You cannot access this page! please login first");
 	header('location: admin login.php');

 }

?>