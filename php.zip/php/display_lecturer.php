<?php include("php/DbConnect.php");  ?>
<?php

 //LOGIN ADMIN


  if(isset($_GET['email']))
  {
    $email=$_GET['email'];
    $query=mysqli_query($db,"SELECT * FROM admintbl WHERE email='$email' ");
    $dataa=mysqli_fetch_array($query);
    $adminid=$dataa['adminid'];
    $email=$dataa['email'];
    $username=$dataa['username'];
    $lastname=$dataa['lastname'];
    $email=$dataa['email'];
    $phoneno=$dataa['phoneno'];
    $department=$dataa['department'];
    $active=$dataa['active'];
     $images=$dataa['images'];
   
  }else{
   
  
  }
  ?>


   <?php

 //LOGIN LECTURER


  if(isset($_GET['email']))
  {
    $email=$_GET['email'];
    $queryl=mysqli_query($db,"SELECT * FROM lecturerstbl WHERE lemail='$email' ");
    $dataal=mysqli_fetch_array($queryl);
    $lecturersidl=$dataal['lecturersid'];
    $surnamel=$dataal['surname'];
    $firstnamel=$dataal['lfirstname'];
    $lastnamel=$dataal['llastname'];
    $emaill=$dataal['lemail'];
    $phonenol=$dataal['lphoneno'];
    $coursecodel=$dataal['coursecode'];
    $titlel=$dataal['title'];
     $imagesl=$dataal['images'];
   
  }else{
   
  
  }
  ?>

   <?php
     //FETCH LECTURER COURSES
       $lecturersidl=$dataal['lecturersid'];
     $sqlleccourse = "SELECT * FROM coursetbl ct INNER JOIN lecturerstbl lt ON ct.course_code=lt.coursecode WHERE lecturersid='$lecturersidl'";
    $resultleccourse = mysqli_query($db, $sqlleccourse);
 
  ?>

   <?php
     //FETCH STUDENTS COURSES
        $coursecodel=$dataal['coursecode'];
     $sqlllecstudents = "SELECT * FROM course_reg_tbl crt INNER JOIN studentstbl st ON crt.admno=st.admno WHERE course_code='$coursecodel'";
    $resultllecstudents = mysqli_query($db, $sqlllecstudents);
 
  ?>
<?php 
 //FETCH STUDENTS EXAMS
        $coursecodel=$dataal['coursecode'];
     $sqlEX = "SELECT * FROM  exams_tbl et INNER JOIN studentstbl st ON et.admno=st.admno WHERE course_code='$coursecodel'";
    $resultEX = mysqli_query($db, $sqlEX);


?>

<?php 
 //FETCH STUDENTS EXAMS
        $lecturersidl=$dataal['lecturersid'];
     $sqlEXl = "SELECT * FROM  exams_tbl et INNER JOIN studentstbl st ON et.admno=st.admno INNER JOIN lecturerstbl lt ON lt.lecturersid=et.lecturersid WHERE lt.lecturersid='$lecturersidl'";
    $resultEXl = mysqli_query($db, $sqlEXl);


?>