<?php include('DbConnect.php'); ?>
<?php
//count all students
 $count = $db->query("SELECT COUNT(*) FROM studentstbl");
 $row = mysqli_fetch_array($count);

 $total = $row[0];

?>


<?php
//count all admins
 $counta = $db->query("SELECT COUNT(*) FROM admintbl");
 $rowa = mysqli_fetch_array($counta);

 $totala = $rowa[0];

?>

<?php
//count all lecturers
 $countl = $db->query("SELECT COUNT(*) FROM lecturerstbl");
 $rowl = mysqli_fetch_array($countl);

 $totall = $rowl[0];

?>

<?php
//count all Courses
 $countc = $db->query("SELECT COUNT(*) FROM coursetbl");
 $rowc = mysqli_fetch_array($countc);

 $totalc = $rowc[0];

?>