<?php include("php/DbConnect.php"); ?>
<?php

  //include('php/save_to_db.php');


  if(isset($_GET['np']))
  {
    $np=$_GET['np'];
    $query=mysqli_query($db,"SELECT * FROM studentstbl WHERE sno='$np' ");
    $data=mysqli_fetch_array($query);
     $national_id=$data['national_id'];
    $admno=$data['admno'];
    $firstname=$data['firstname'];
    $middlename=$data['middlename'];
    $lastname=$data['lastname'];
    $email=$data['email'];
    $gender=$data['gender'];
    $phoneno=$data['phoneno'];
    $dateofbirth=$data['dateofbirth'];
    $program=$data['program'];
    $region=$data['region'];
   
  }else{
   
  
  }
  ?>

  <?php


  if(isset($_GET['nl']))
  {
    $nl=$_GET['nl'];
    $query=mysqli_query($db,"SELECT * FROM lecturerstbl WHERE lecturersid='$nl' ");
    $data=mysqli_fetch_array($query);
    $lecturersid=$data['lecturersid'];
    $sirname=$data['sirname'];
    $lfirstname=$data['lfirstname'];
    $llastname=$data['llastname'];
    $lemail=$data['lemail'];
    $lphoneno=$data['lphoneno'];
   
    $title=$data['title'];
   
  }else{
   
  
  }
  ?>


  <?php
//update fees
  if(isset($_GET['nu']))
  {
    $nu=$_GET['nu'];
    $query=mysqli_query($db,"SELECT * FROM fees_tbl WHERE admno='$nu' ");
    $data=mysqli_fetch_array($query);
    $admno=$data['admno'];
   
   
  }else{
    
  
  }
  ?>


   <?php

  //include('php/save_to_db.php');


  if(isset($_GET['na']))
  {
    $na=$_GET['na'];
    $query=mysqli_query($db,"SELECT * FROM admintbl WHERE adminid='$na' ");
    $data=mysqli_fetch_array($query);
    $adminid=$data['adminid'];
    $username=$data['username'];
    $lastname=$data['lastname'];
    $email=$data['email'];
    $phoneno=$data['phoneno'];
    $department=$data['department'];
    $active=$data['active'];
   
  }else{
  
  
  }
  ?>

  <?php

 //VIEW STUDENTS


  if(isset($_GET['nvs']))
  {
    $nvs=$_GET['nvs'];
    $query=mysqli_query($db,"SELECT * FROM studentstbl WHERE admno='$nvs' ");
    $data=mysqli_fetch_array($query);
    $admno=$data['admno'];
    $firstname=$data['firstname'];
    $middlename=$data['middlename'];
    $lastname=$data['lastname'];
    $email=$data['email'];
    $gender=$data['gender'];
    $phoneno=$data['phoneno'];
    $dateofbirth=$data['dateofbirth'];
    $program=$data['program'];
    $region=$data['region'];
     $images=$data['images'];
   
  }else{
   
  
  }
  ?>


  <?php
//update fees
  if(isset($_GET['emailC']))
  {
    $emailC=$_GET['emailC'];
    $query=mysqli_query($db,"SELECT * FROM lecturerstbl WHERE lemail='$emailC' ");
    $data=mysqli_fetch_array($query);
    $lecturersid=$data['lecturersid'];
     $lfirstname=$data['lfirstname'];
      $llastname=$data['llastname'];
       $lemail=$data['lemail'];
        $surname=$data['surname'];
   
   
  }else{
    
  
  }
  ?>

  


    